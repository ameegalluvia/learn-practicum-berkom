# NIM/Nama  : 16026289/Abdus Salam Faiz
# Tanggal   : 15 Oktober 2026
# Deskripsi : Program untuk mengubah masukan integer ABC digabung menjadi bilangan terbesar dari penyusun penyusunnya

a = int(input("Masukkan kartu A: "))
b = int(input("Masukkan kartu B: "))
c = int(input("Masukkan kartu C: "))

susunan = 0

a_baru = 0
b_baru = 0
c_baru = 0

a_new = 0
b_new = 0
c_new = 0

jumlah_digit = 100

if a >= 10:
    a_baru = (a * 10) // 100
    jumlah_digit *= 10
elif a < 10:
    a_baru = a

if b >= 10:
    b_baru = (b * 10) // 100
    jumlah_digit *= 10
elif b < 10:
    b_baru = b

if c >= 10:
    c_baru = (c * 10) // 100
    jumlah_digit *= 10
elif c < 10:
    c_baru = c


if a_baru > b_baru and a_baru > c_baru:
    if a < 10:
        a_new = a * jumlah_digit
        a_baru = 0
    else:
        a_new = a * (jumlah_digit / 10)
        a_baru = 0
elif b_baru > a_baru and b_baru > c_baru:
    if  b < 10:
        b_new = b * jumlah_digit
        b_baru = 0
    else:
        b_new = b * (jumlah_digit / 10)
        b_baru = 0
elif c_baru > a_baru and c_baru > b_baru:
    if c < 10:
        c_new = c * jumlah_digit
        c_baru = 0
    else:
        c_new = c * (jumlah_digit / 10)
        c_baru = 0

if a_baru > b_baru and a_baru > c_baru:
    if a < 10:
        a_new = a * (jumlah_digit / 10)
        a_baru = 0
    else:
        a_new = a * (jumlah_digit / 100)
        a_baru = 0
elif b_baru > a_baru and b_baru > c_baru:
    if b < 10:
        b_new = b * (jumlah_digit / 10)
        b_baru = 0
    else:
        b_new = b * (jumlah_digit / 100)
        b_baru = 0
elif c_baru > a_baru and c_baru > b_baru:
    if c < 10:
        c_new = c * (jumlah_digit / 10)
        c_baru = 0
    else:
        c_new = c * (jumlah_digit / 100)
        c_baru = 0

if a_baru > b_baru and a_baru > c_baru:
    if a < 10:
        a_new = a * (jumlah_digit / 100)
        a_baru = 0
    else:
        a_new = a * (jumlah_digit / 1000)
        a_baru = 0
elif b_baru > a_baru and b_baru > c_baru:
    if b < 10:
        b_new = b * (jumlah_digit / 100)
        b_baru = 0
    else:
        b_new = b * (jumlah_digit / 1000)
        b_baru = 0
elif c_baru > a_baru and c_baru > b_baru:
    if c < 10:
        c_new = c * (jumlah_digit / 10)
        c_baru = 0
    else:
        c_new = c * (jumlah_digit / 1000)
        c_baru = 0

susunan = (a_new + b_new + c_new) / jumlah_digit

print(susunan)